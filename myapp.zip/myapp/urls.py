from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home,name='Homep'),
    path('About',views.about,name='About'),
    path('Services',views.services,name='Services'),
    path('Packages',views.packages,name='Packages'),
    path('Contact',views.contact,name='Contact'),
    path('Registration/Login',views.registration,name='Registration/Login'),
    
    
]
