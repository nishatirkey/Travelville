from django.shortcuts import render,HttpResponse,redirect
from .models import * 
# Create your views here.


def home(request):
    return render(request,'home.html')


def about(request):
    return render (request,'about.html')

def services(request):
    return render (request,'services.html')

def packages(request):
    return render (request,'packages.html')


def contact(request):
    if request.method == 'POST':
        firstname=request.POST["firstname"]
        lastname=request.POST["lastname"]
        email=request.POST["email"]
        contactnumber=request.POST["contactnumber"]
        message=request.POST["message"]
        print(firstname,lastname,email,contactnumber,message)
        ContactUs.objects.create(
            firstname=firstname,
            lastname=lastname,
            email=email,
            contactnumber=contactnumber,
            message=message

        )
        return redirect('/Contact')
    

    return render (request,'contact.html')


def registration(request):
    if request.method == 'POST':
        name=request.POST["username"]
        email=request.POST["email"]
        password=request.POST["password"]
        print(name,email,password)
        Register.objects.create(
            username=name,
            email=email,
            password=password

        )
        return redirect('/Registration/Login')

        
    return render (request,'registration.html')






