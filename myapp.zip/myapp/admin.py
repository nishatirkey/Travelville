from django.contrib import admin
from .models import *
# Register your models here.
#admin.site.register(Register)
@admin.register(Register)
class Adminuser(admin.ModelAdmin):
    list_display=['username','email','password']

@admin.register(ContactUs)  
class ContactUs(admin.ModelAdmin):
    list_display=['firstname', 'lastname','email','contactnumber','message']
